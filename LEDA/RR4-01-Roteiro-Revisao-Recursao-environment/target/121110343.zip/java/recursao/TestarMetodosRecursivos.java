package recursao;

public class TestarMetodosRecursivos {
	public static void main(String[] args) {
		// preencha esse metodo com codigo para testar a classe MetodosRecursivos.
		//System.out.println(MetodosRecursivos.calcularFatorial(5));
		
		//System.out.println(MetodosRecursivos.calcularFibonacci(5));
		
//		Object[] string = {"obj1", null,"obj3", "obj4", null};
//		
//		System.out.println(MetodosRecursivos.countNotNull(string, 0));
		
		//System.out.println(MetodosRecursivos.potenciaDe2(-10));
		
		//PA = 2, 6, 10, 14, 18
//		System.out.println(MetodosRecursivos.progressaoAritmetica(2, 4, 7));
		
		//PG = 2, 4, 8, 16, 32, 64
		System.out.println(MetodosRecursivos.progressaoGeometrica(2, 2, 6));
		//PG2 = 10, 100, 1000, 10000
		System.out.println(MetodosRecursivos.progressaoGeometrica(10, 10, 6));

	}
}
